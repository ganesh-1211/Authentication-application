package com.example.auth_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
