// lib/providers/auth_provider.dart
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:auth_app/models/user.dart';
import 'package:auth_app/utils/api.dart';
import 'package:jwt_decoder/jwt_decoder.dart';

class AuthProvider with ChangeNotifier {
  User? _user;
  String? _token;
  List<User> _allUsers = [];
  bool _isLoading = false;

  User? get user => _user;
  String? get token => _token;
  List<User> get allUsers => _allUsers;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _token != null;

  final _storage = const FlutterSecureStorage();
  final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);

  // Check if token exists and is valid
  Future<bool> checkAuthentication() async {
    _token = await _storage.read(key: 'token');
    
    if (_token != null) {
      try {
        // Check if token is expired
        if (JwtDecoder.isExpired(_token!)) {
          await logout();
          return false;
        }
        
        // Get user information
        await getCurrentUser();
        return true;
      } catch (e) {
        await logout();
        return false;
      }
    }
    return false;
  }

  // Register new user
  Future<bool> register(String name, String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      final response = await http.post(
        Uri.parse('${Api.baseUrl}/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      _isLoading = false;
      
      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        _token = data['token'];
        _user = User.fromJson(data['user']);
        
        // Save token
        await _storage.write(key: 'token', value: _token);
        
        notifyListeners();
        return true;
      } else {
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Login with email and password
  Future<bool> login(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      final response = await http.post(
        Uri.parse('${Api.baseUrl}/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      _isLoading = false;
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _token = data['token'];
        _user = User.fromJson(data['user']);
        
        // Save token
        await _storage.write(key: 'token', value: _token);
        
        // Fetch all users
        await fetchAllUsers();
        
        notifyListeners();
        return true;
      } else {
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Login with Google
  Future<bool> signInWithGoogle() async {
    try {
      _isLoading = true;
      notifyListeners();

      // Begin interactive sign in process
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      
      if (googleUser == null) {
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // Handle Google sign-in on backend
      // Normally, you'd send Google ID token to your server and verify there
      // For simplicity, we're redirecting to your backend's Google auth route

      // Here we're simplifying the flow. In a real app:
      // 1. Get GoogleSignInAuthentication
      // 2. Send idToken to backend for verification
      // 3. Get JWT token back from your server
      
      // Open browser to authenticate with backend
      // This is a placeholder - in a real app, you'd implement a proper OAuth flow
      // You might use a WebView or direct API call to your backend
      
      // For demo purposes:
      // Assume we got token from backend after Google auth
      final response = await http.post(
        Uri.parse('${Api.baseUrl}/auth/google/mobile'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': googleUser.email,
          'name': googleUser.displayName,
          'googleId': googleUser.id,
          'profilePic': googleUser.photoUrl,
        }),
      );
      
      _isLoading = false;
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _token = data['token'];
        _user = User.fromJson(data['user']);
        
        // Save token
        await _storage.write(key: 'token', value: _token);
        
        // Fetch all users
        await fetchAllUsers();
        
        notifyListeners();
        return true;
      } else {
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Get current user
  Future<void> getCurrentUser() async {
    try {
      if (_token == null) return;
      
      final response = await http.get(
        Uri.parse('${Api.baseUrl}/auth/me'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_token',
        },
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _user = User.fromJson(data['user']);
        
        // Fetch all users
        await fetchAllUsers();
        
        notifyListeners();
      } else {
        await logout();
      }
    } catch (e) {
      await logout();
    }
  }

  // Fetch all users
  Future<void> fetchAllUsers() async {
    try {
      if (_token == null) return;
      
      final response = await http.get(
        Uri.parse('${Api.baseUrl}/users'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_token',
        },
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        _allUsers = data.map((user) => User.fromJson(user)).toList();
        notifyListeners();
      }
    } catch (e) {
      // Handle error
    }
  }

  // Logout
  Future<void> logout() async {
    _user = null;
    _token = null;
    _allUsers = [];
    await _storage.delete(key: 'token');
    await _googleSignIn.signOut();
    notifyListeners();
  }
}