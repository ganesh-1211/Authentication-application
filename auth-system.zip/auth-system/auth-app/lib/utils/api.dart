// lib/utils/api.dart
class Api {
  // Change this to your actual API URL
  static const String baseUrl = 'http://10.0.2.2:5000/api';
}
