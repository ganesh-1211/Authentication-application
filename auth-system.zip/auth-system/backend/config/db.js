// config/db.js
const mongoose = require('mongoose');

// MongoDB connection function with retry logic
const connectDB = async (retryCount = 5, retryDelay = 5000) => {
  let currentRetry = 0;
  
  const tryConnect = async () => {
    try {
      const conn = await mongoose.connect(process.env.MONGO_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        // Connection pool settings
        poolSize: 10, // Default is 5
        socketTimeoutMS: 45000, // Close sockets after 45 seconds of inactivity
        family: 4, // Use IPv4, skip trying IPv6
      });
      
      console.log(`MongoDB Connected: ${conn.connection.host}`);
      
      // Monitor the connection
      mongoose.connection.on('error', (err) => {
        console.error(`MongoDB connection error: ${err}`);
        if (err.name === 'MongoNetworkError') {
          reconnect();
        }
      });
      
      mongoose.connection.on('disconnected', () => {
        console.log('MongoDB disconnected');
        reconnect();
      });
      
      // Handle application termination
      process.on('SIGINT', async () => {
        await mongoose.connection.close();
        console.log('MongoDB connection closed due to app termination');
        process.exit(0);
      });
      
      return conn;
    } catch (error) {
      console.error(`Error connecting to MongoDB: ${error.message}`);
      return reconnect();
    }
  };
  
  const reconnect = async () => {
    currentRetry++;
    if (currentRetry <= retryCount) {
      console.log(`Retrying MongoDB connection (${currentRetry}/${retryCount}) in ${retryDelay/1000} seconds...`);
      await new Promise(resolve => setTimeout(resolve, retryDelay));
      return tryConnect();
    } else {
      console.error(`Failed to connect to MongoDB after ${retryCount} attempts.`);
      process.exit(1); // Exit with failure
    }
  };
  
  return tryConnect();
};

module.exports = connectDB;