// controllers/errorController.js

// Handle 404 errors
exports.notFound = (req, res, next) => {
    const error = new Error(`Not Found - ${req.originalUrl}`);
    res.status(404);
    next(error);
  };
  
  // Global error handler
  exports.errorHandler = (err, req, res, next) => {
    // Set status code (use error's status code or default to 500)
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    
    // Log error for server-side debugging
    console.error(`Error: ${err.message}`);
    console.error(err.stack);
    
    // Send error response to client
    res.status(statusCode).json({
      message: err.message,
      stack: process.env.NODE_ENV === 'production' ? '🥞' : err.stack,
    });
  };
  
  // Specific error types
  exports.handleValidationError = (err, res) => {
    const errors = Object.values(err.errors).map(error => error.message);
    res.status(400).json({ message: 'Validation failed', errors });
  };
  
  exports.handleDuplicateKeyError = (err, res) => {
    const field = Object.keys(err.keyValue)[0];
    res.status(400).json({ 
      message: `An account with that ${field} already exists.` 
    });
  };
  
  // Enhanced error handler with specific error types
  exports.enhancedErrorHandler = (err, req, res, next) => {
    // Mongoose validation error
    if (err.name === 'ValidationError') {
      return this.handleValidationError(err, res);
    }
    
    // Mongoose duplicate key error
    if (err.code === 11000) {
      return this.handleDuplicateKeyError(err, res);
    }
    
    // JWT errors
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token. Please log in again.' });
    }
    
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Your token has expired! Please log in again.' });
    }
    
    // Default to the standard error handler
    return this.errorHandler(err, req, res, next);
  };