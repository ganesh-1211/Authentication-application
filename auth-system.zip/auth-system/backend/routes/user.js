// routes/user.js
const express = require('express');
const { authMiddleware } = require('../middleware/auth');
const userController = require('../controllers/userController');

const router = express.Router();

// User routes
router.get('/', authMiddleware, userController.getAllUsers);
router.get('/me', authMiddleware, userController.getCurrentUser);
router.get('/:id', authMiddleware, userController.getUserById);
router.put('/profile', authMiddleware, userController.updateProfile);
router.delete('/:id', authMiddleware, userController.deleteUser);

module.exports = router;